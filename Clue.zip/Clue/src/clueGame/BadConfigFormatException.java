package clueGame;

public class BadConfigFormatException {
	private int rows;
	private int cols;

	public BadConfigFormatException() {
		// TODO Auto-generated constructor stub
	}

}
