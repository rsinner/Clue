package clueGame;

public class WalkwayCell extends BoardCell {

	public WalkwayCell() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public boolean isWalkway() {
		return true;
	}
	

}
