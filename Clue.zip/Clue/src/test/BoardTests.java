package test;

import static org.junit.Assert.*;

import org.junit.Test;

import clueGame.BadConfigFormatException;
import clueGame.Board;
import clueGame.BoardCell;
import clueGame.RoomCell;

public class BoardTests {
	private static Board board;

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
